<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Create admin user
        User::create([
            'name' => 'Admin VibeGet',
            'email' => 'admin@vibeget.com',
            'password' => Hash::make('admin123'),
            'cpf' => '00000000000',
            'phone' => '(11) 99999-9999',
            'balance' => 1000.00,
            'cashback_balance' => 0,
            'is_admin' => true,
            'is_active' => true,
            'email_verified_at' => now(),
        ]);

        // Create test user
        User::create([
            'name' => 'Usuário Teste',
            'email' => 'usuario@teste.com',
            'password' => Hash::make('teste123'),
            'cpf' => '11111111111',
            'phone' => '(11) 88888-8888',
            'balance' => 500.00,
            'cashback_balance' => 50.00,
            'is_admin' => false,
            'is_active' => true,
            'email_verified_at' => now(),
        ]);
    }
}

<?php

use App\Http\Controllers\Api\AuthController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

// Public routes
Route::prefix('auth')->group(function () {
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/login', [AuthController::class, 'login']);
});

// Health check
Route::get('/health', function () {
    return response()->json([
        'success' => true,
        'message' => 'VibeGet API is running',
        'timestamp' => now()->toIso8601String(),
    ]);
});

// Public settings route
Route::get('/settings/public', [\App\Http\Controllers\Api\SettingsController::class, 'getPublic']);

// Protected routes
Route::middleware('auth:sanctum')->group(function () {
    // Auth routes
    Route::prefix('auth')->group(function () {
        Route::get('/me', [AuthController::class, 'me']);
        Route::post('/logout', [AuthController::class, 'logout']);
        Route::post('/logout-all', [AuthController::class, 'logoutAll']);
        Route::put('/profile', [AuthController::class, 'updateProfile']);
        Route::put('/change-password', [AuthController::class, 'changePassword']);
    });

    // User routes
    Route::prefix('user')->group(function () {
        Route::get('/', function (Request $request) {
            return response()->json([
                'success' => true,
                'data' => $request->user()
            ]);
        });
        
        Route::get('/balance', function (Request $request) {
            return response()->json([
                'success' => true,
                'data' => [
                    'balance' => $request->user()->balance,
                    'cashback_balance' => $request->user()->cashback_balance,
                ]
            ]);
        });
    });

    // Admin only routes
    Route::middleware('admin')->group(function () {
        // Settings management
        Route::prefix('settings')->group(function () {
            Route::get('/', [\App\Http\Controllers\Api\SettingsController::class, 'index']);
            Route::get('/group/{group}', [\App\Http\Controllers\Api\SettingsController::class, 'getByGroup']);
            Route::put('/{key}', [\App\Http\Controllers\Api\SettingsController::class, 'update']);
            Route::post('/batch', [\App\Http\Controllers\Api\SettingsController::class, 'updateBatch']);
            Route::post('/upload-image', [\App\Http\Controllers\Api\SettingsController::class, 'uploadImage']);
        });
    });
});

